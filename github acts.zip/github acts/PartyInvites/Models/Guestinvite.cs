﻿using System.ComponentModel.DataAnnotations;
namespace PartyInvites.Models
{
    public class Guestinvite
    {
        [Required(ErrorMessage ="Please Enter Name.")]
        public string? Name { get; set; }
        [Required(ErrorMessage = "Please Input Email Address.")]
        public string? Email { get; set; }
        [Required(ErrorMessage = "Please input Phone Number.")]
        public string? Phone { get; set; }
        [Required(ErrorMessage = "Choose specified if you will attend.")]
        public bool? WillAttend { get; set; }
    }
}
