﻿namespace PartyInvites.Models
{
    public static class Repository
    {
        private static List<Guestinvite> responses = new ();

        public static IEnumerable<Guestinvite> Response => responses;

        public static void AddResponse(Guestinvite response)
        { 
            Console.WriteLine(response);
            responses.Add(response);
        }
    }
}
